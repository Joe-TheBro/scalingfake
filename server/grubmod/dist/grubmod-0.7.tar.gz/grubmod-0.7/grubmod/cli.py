import click
import errno
import sys
import os

@click.command()
@click.option('--kernel-version', help='Kernel version to target')
def modify_grub(kernel_version):
    print(f'Modifying GRUB for kernel version {kernel_version}')
    output = []
    in_section = False
    try: 
        with open('/boot/grub/grub.cfg', 'r') as f:
            lines = f.readlines()
            for line in lines:
                section_start = f"menuentry 'Ubuntu, with Linux {kernel_version}'"
                if line.strip().find(section_start) > -1:
                    print("DEBUG: FOUND SECTION")
                    in_section = True
                    output.append(line)
                    continue
                if in_section and line.strip() == '}':
                    print("DEBUG: END OF SECTION")
                    in_section = False
                    output.append(line)
                    continue
                if in_section and line.strip() in {'if [ "${initrdfail}" = 1 ]; then'}:
                    print("DEBUG: SKIPPING SECTION")
                    # skip this line and the next 5 lines
                    for _ in range(6):
                        next(f)
                    continue
                if in_section and line.strip() in {'fi', 'initrdfail'}:
                    continue
                output.append(line)
    except IOError as e:
        if e.errno == errno.EPERM:
            print('Permission denied. Please run this script as root.')
            sys.exit(1)
        if e.errno == errno.ENOENT:
            print('GRUB config not found, exiting.')
            sys.exit(1)
    temp_file = '/boot/grub/grub.cfg.temp'
    with open(temp_file, 'w') as f:
        f.write(''.join(output))
    # replace the original file with the modified file
    try:
        os.rename(temp_file, '/boot/grub/grub.cfg')
    except PermissionError:
        print('Permission denied. Please run this script as root.')
        sys.exit(1)
    print('GRUB modified successfully.')

if __name__ == '__main__':
    modify_grub()